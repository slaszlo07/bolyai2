print(2+3)
print("2"+"3"")
a=12
b=3
print("a"+"b")
print(20*"a")
print("Szorgalmasan gyakorolni\nfogom a programozást")
print("alma","körte","citrom",sep="-",end="")
print("gvlbihfguhb")