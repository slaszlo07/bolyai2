# bolyai
Sefcsik László (TECH2022B)
